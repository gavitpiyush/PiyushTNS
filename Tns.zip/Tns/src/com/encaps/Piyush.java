package com.encaps;
import java.util.Scanner;

class Piyush {
    public static void main(String[] args) {
        for(int j=10;j<=20;j++){
            System.out.println("Table of "+j+":");
            for(int i=1;i<=10;i++){
                System.out.println(i*j);
            }
            System.out.println("Table of "+j+" completed");
            System.out.println(" ");
        }
    }
}



